
//定义一个包含多个对象的json字符串
var laJsonStr = '{ "languages":[{"language1":"html"},{"language2":"js"},{"language3":"css"}]}';
//将json字符串解析为json对象，此函数存在脚本执行风险，一般不使用此方法，而是使用json解析器解析
var laJson = eval("(" + laJsonStr + ")");
//通过json解析器反序列化（将json字符串转换为json对象）
var laJson2 = JSON.parse(laJsonStr);
//通过json对象.key或者json对象[key]获取value
var stra2 = "<h1 st>"+laJson2.languages[0].language1 + '/' + laJson2.languages[1].language2 + '/' + laJson2.languages[2].language3 +"</h1>";
//通过json解析器序列化（将json对象转换为json字符串）
var laJsonStr3 = JSON.stringify(laJson2);
         
document.write(stra2);
//获取yyyy-mm-dd
function getYearMonthDate(){
    var nowFullDate = new Date();
    var year = nowFullDate.getFullYear();
    var month = nowFullDate.getMonth + 1;
    var nowDate = nowFullDate.getDate();
    if(month < 10){
        month = '0' + month; 
    }
    if(nowDate < 10){
        nowDate = '0' + month; 
    }
    var yearMonthDate = year + '-' + month + nowDate;
    return yearMonthDate;
}
//求和
function getSum(){
    var retunSum = 0;
    var err = new Error();
    alert(typeof(1.1));
    try{
        for(var i = 0; i < arguments.length; i++){
            if(typeof(arguments[i] != "number")){
                err = "不是一个数字";
                throw err;
            }
            retunSum += arguments[i];
        }
    }catch(e){
            alert(e);
    }finally{
        return retunSum;
    }

}
//正则表达式
function myRegEx(str,regEx){
    if(str.match(regEx)){
        return true;
    }else{
        return false;
    }
}


var xmlDoc = new ActiveXObject("Microsoft.XMLDOM")
xmlDoc.async="false"
xmlDoc.validateOnParse="true"
xmlDoc.load("xml/note.xml")

document.write("<br>Error Code: ")
document.write(xmlDoc.parseError.errorCode)
document.write("<br>Error Reason: ")
document.write(xmlDoc.parseError.reason)
document.write("<br>Error Line: ")
document.write(xmlDoc.parseError.line)